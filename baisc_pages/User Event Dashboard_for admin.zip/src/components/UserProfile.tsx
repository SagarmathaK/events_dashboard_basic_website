import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ArrowLeft, Mail, User, GraduationCap, Building2, Calendar } from "lucide-react";

interface UserRegistration {
  id: number;
  username: string;
  email: string;
  eventsParticipated: string[];
  department: string;
  undergradYear: number;
}

interface UserProfileProps {
  user: UserRegistration;
  onBack: () => void;
  logo: string;
}

export function UserProfile({ user, onBack, logo }: UserProfileProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-2">
        <img src={logo} alt="B.M.S. College of Engineering" className="w-16 h-16" />
        <div className="flex-1">
          <h1 className="text-white">User Profile</h1>
          <p className="text-white/80">
            Detailed information and event participation
          </p>
        </div>
        <Button onClick={onBack} variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
      </div>

      {/* User Information Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            User Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground">
                <User className="h-4 w-4" />
                <span className="text-sm">Username</span>
              </div>
              <p className="text-lg">{user.username}</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span className="text-sm">Email</span>
              </div>
              <p className="text-lg">{user.email}</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Building2 className="h-4 w-4" />
                <span className="text-sm">Department</span>
              </div>
              <Badge variant="outline" className="text-sm px-3 py-1">
                {user.department}
              </Badge>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground">
                <GraduationCap className="h-4 w-4" />
                <span className="text-sm">Undergraduate Year</span>
              </div>
              <Badge variant="secondary" className="text-sm px-3 py-1">
                Year {user.undergradYear}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Events Participated Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Events Participated ({user.eventsParticipated.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {user.eventsParticipated.map((event, idx) => (
              <div
                key={idx}
                className="p-4 rounded-lg border bg-card hover:bg-accent transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">{event}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Event #{idx + 1}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {user.eventsParticipated.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No events participated yet
            </p>
          )}
        </CardContent>
      </Card>

      {/* Statistics Card */}
      <Card>
        <CardHeader>
          <CardTitle>Participation Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 rounded-lg bg-primary/10">
              <div className="text-3xl mb-2">{user.eventsParticipated.length}</div>
              <p className="text-sm text-muted-foreground">Total Events</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-primary/10">
              <div className="text-3xl mb-2">{user.department}</div>
              <p className="text-sm text-muted-foreground">Department</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-primary/10">
              <div className="text-3xl mb-2">Year {user.undergradYear}</div>
              <p className="text-sm text-muted-foreground">Current Year</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
