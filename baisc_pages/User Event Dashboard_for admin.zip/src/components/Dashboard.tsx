import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Users, Search } from "lucide-react";
import { useState } from "react";

interface DashboardProps {
  logo: string;
  onUserClick: (userId: number) => void;
}

// Department options
const DEPARTMENTS = [
  { acronym: "CSE", fullName: "Computer Science and Engineering" },
  { acronym: "ISE", fullName: "Information Science and Engineering" },
  { acronym: "ECE", fullName: "Electronics and Communication Engineering" },
  { acronym: "EEE", fullName: "Electrical and Electronics Engineering" },
  { acronym: "ME", fullName: "Mechanical Engineering" },
  { acronym: "CE", fullName: "Civil Engineering" },
  { acronym: "IEM", fullName: "Industrial Engineering and Management" },
  { acronym: "ETE", fullName: "Electronics and Telecommunication Engineering" },
  { acronym: "AE", fullName: "Aerospace Engineering" },
  { acronym: "AU", fullName: "Automobile Engineering" },
  { acronym: "AI & ML", fullName: "Artificial Intelligence and Machine Learning" },
  { acronym: "BT", fullName: "Biotechnology" },
  { acronym: "MLE", fullName: "Medical Electronics Engineering" },
  { acronym: "RME", fullName: "Robotics and Mechatronics Engineering" }
];

// Mock data for registered users
const mockRegistrations = [
  {
    id: 1,
    username: "alice_johnson",
    email: "alice.johnson@university.edu",
    eventsParticipated: ["Tech Summit 2025", "AI Workshop", "Hackathon Spring"],
    department: "CSE",
    undergradYear: 3
  },
  {
    id: 2,
    username: "bob_smith",
    email: "bob.smith@university.edu",
    eventsParticipated: ["Career Fair", "Alumni Meetup"],
    department: "EEE",
    undergradYear: 4
  },
  {
    id: 3,
    username: "carol_white",
    email: "carol.white@university.edu",
    eventsParticipated: ["Tech Summit 2025", "Data Science Symposium", "Research Conference", "Networking Night"],
    department: "ISE",
    undergradYear: 2
  },
  {
    id: 4,
    username: "david_brown",
    email: "david.brown@university.edu",
    eventsParticipated: ["Hackathon Spring"],
    department: "CSE",
    undergradYear: 1
  },
  {
    id: 5,
    username: "emma_davis",
    email: "emma.davis@university.edu",
    eventsParticipated: ["AI Workshop", "Tech Summit 2025", "Career Fair"],
    department: "AI & ML",
    undergradYear: 4
  },
  {
    id: 6,
    username: "frank_wilson",
    email: "frank.wilson@university.edu",
    eventsParticipated: ["Research Conference", "Alumni Meetup"],
    department: "ME",
    undergradYear: 3
  },
  {
    id: 7,
    username: "grace_taylor",
    email: "grace.taylor@university.edu",
    eventsParticipated: ["Data Science Symposium", "Networking Night", "Career Fair"],
    department: "ISE",
    undergradYear: 2
  },
  {
    id: 8,
    username: "henry_martinez",
    email: "henry.martinez@university.edu",
    eventsParticipated: ["Tech Summit 2025", "Hackathon Spring", "AI Workshop"],
    department: "CSE",
    undergradYear: 3
  }
];

export function Dashboard({ logo, onUserClick }: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [yearFilter, setYearFilter] = useState("all");

  // Get unique years for filters
  const years = Array.from(new Set(mockRegistrations.map(r => r.undergradYear))).sort((a, b) => a - b);

  // Filter registrations based on search and filters
  const filteredRegistrations = mockRegistrations.filter(reg => {
    const matchesSearch = 
      reg.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.eventsParticipated.some(event => event.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesDepartment = departmentFilter === "all" || reg.department === departmentFilter;
    const matchesYear = yearFilter === "all" || reg.undergradYear === parseInt(yearFilter);

    return matchesSearch && matchesDepartment && matchesYear;
  });

  // Calculate statistics
  const totalUsers = mockRegistrations.length;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-2">
        <img src={logo} alt="B.M.S. College of Engineering" className="w-16 h-16" />
        <div>
          <h1 className="text-white">Event Registration Dashboard</h1>
          <p className="text-white/80">
            Overview of all registered users and their event participation
          </p>
          <p className="text-white/90 mt-8 text-lg">
            Event Name: <span className="font-semibold">Tech Summit 2025</span>
          </p>
        </div>
      </div>

      {/* Statistics Cards */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Total Registrations</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalUsers}</div>
          <p className="text-xs text-muted-foreground">
            Active users in the system
          </p>
        </CardContent>
      </Card>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle>User Registrations</CardTitle>
          <CardDescription>
            Filter and search through all event registrations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by username, email, or event..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="All Departments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {DEPARTMENTS.map(department => (
                  <SelectItem key={department.acronym} value={department.acronym}>
                    {department.fullName} ({department.acronym})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="All Years" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                {years.map(year => (
                  <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="-ml-3">Department</TableHead>
                  <TableHead>Year</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRegistrations.length > 0 ? (
                  filteredRegistrations.map((registration) => (
                    <TableRow key={registration.id}>
                      <TableCell>
                        <button
                          onClick={() => onUserClick(registration.id)}
                          className="text-primary hover:underline cursor-pointer"
                        >
                          {registration.username}
                        </button>
                      </TableCell>
                      <TableCell>{registration.email}</TableCell>
                      <TableCell className="-ml-3">
                        <Badge variant="outline">{registration.department}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{registration.undergradYear}</Badge>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      No registrations found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {/* Results count */}
          <p className="text-sm text-muted-foreground">
            Showing {filteredRegistrations.length} of {totalUsers} registrations
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
