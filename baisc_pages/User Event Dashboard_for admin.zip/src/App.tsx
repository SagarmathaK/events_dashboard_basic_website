import { useState } from "react";
import { Dashboard } from "./components/Dashboard";
import { UserProfile } from "./components/UserProfile";
import logo from "figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png";

// Mock data for registered users (same as in Dashboard)
const mockRegistrations = [
  {
    id: 1,
    username: "alice_johnson",
    email: "alice.johnson@university.edu",
    eventsParticipated: ["Tech Summit 2025", "AI Workshop", "Hackathon Spring"],
    department: "CSE",
    undergradYear: 3
  },
  {
    id: 2,
    username: "bob_smith",
    email: "bob.smith@university.edu",
    eventsParticipated: ["Career Fair", "Alumni Meetup"],
    department: "EEE",
    undergradYear: 4
  },
  {
    id: 3,
    username: "carol_white",
    email: "carol.white@university.edu",
    eventsParticipated: ["Tech Summit 2025", "Data Science Symposium", "Research Conference", "Networking Night"],
    department: "ISE",
    undergradYear: 2
  },
  {
    id: 4,
    username: "david_brown",
    email: "david.brown@university.edu",
    eventsParticipated: ["Hackathon Spring"],
    department: "CSE",
    undergradYear: 1
  },
  {
    id: 5,
    username: "emma_davis",
    email: "emma.davis@university.edu",
    eventsParticipated: ["AI Workshop", "Tech Summit 2025", "Career Fair"],
    department: "AI & ML",
    undergradYear: 4
  },
  {
    id: 6,
    username: "frank_wilson",
    email: "frank.wilson@university.edu",
    eventsParticipated: ["Research Conference", "Alumni Meetup"],
    department: "ME",
    undergradYear: 3
  },
  {
    id: 7,
    username: "grace_taylor",
    email: "grace.taylor@university.edu",
    eventsParticipated: ["Data Science Symposium", "Networking Night", "Career Fair"],
    department: "ISE",
    undergradYear: 2
  },
  {
    id: 8,
    username: "henry_martinez",
    email: "henry.martinez@university.edu",
    eventsParticipated: ["Tech Summit 2025", "Hackathon Spring", "AI Workshop"],
    department: "CSE",
    undergradYear: 3
  }
];

export default function App() {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  
  const selectedUser = selectedUserId 
    ? mockRegistrations.find(user => user.id === selectedUserId)
    : null;

  return (
    <div className="min-h-screen p-4 md:p-8 relative overflow-hidden" style={{ backgroundColor: '#00306B' }}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400 rounded-full blur-3xl"></div>
        <div className="absolute top-1/4 right-0 w-80 h-80 bg-cyan-300 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-blue-300 rounded-full blur-3xl"></div>
      </div>
      
      {/* Golden Semi-circles */}
      <div className="absolute top-0 right-0 w-64 h-32 opacity-20" style={{
        background: 'rgb(204, 153, 51)',
        borderBottomLeftRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateY(-50%)'
      }}></div>
      <div className="absolute top-0 left-1/4 w-48 h-24 opacity-15" style={{
        background: 'rgb(204, 153, 51)',
        borderBottomLeftRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateY(-50%)'
      }}></div>
      <div className="absolute bottom-0 left-0 w-80 h-40 opacity-15" style={{
        background: 'rgb(204, 153, 51)',
        borderTopLeftRadius: '100%',
        borderTopRightRadius: '100%',
        transform: 'translateY(50%)'
      }}></div>
      <div className="absolute bottom-0 right-1/3 w-56 h-28 opacity-18" style={{
        background: 'rgb(204, 153, 51)',
        borderTopLeftRadius: '100%',
        borderTopRightRadius: '100%',
        transform: 'translateY(50%)'
      }}></div>
      <div className="absolute top-1/3 left-0 w-48 h-24 opacity-10" style={{
        background: 'rgb(204, 153, 51)',
        borderTopRightRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateX(-50%)'
      }}></div>
      <div className="absolute top-1/2 left-0 w-40 h-20 opacity-12" style={{
        background: 'rgb(204, 153, 51)',
        borderTopRightRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateX(-50%)'
      }}></div>
      <div className="absolute bottom-1/4 right-0 w-56 h-28 opacity-12" style={{
        background: 'rgb(204, 153, 51)',
        borderTopLeftRadius: '100%',
        borderBottomLeftRadius: '100%',
        transform: 'translateX(50%)'
      }}></div>
      <div className="absolute top-2/3 right-0 w-44 h-22 opacity-14" style={{
        background: 'rgb(204, 153, 51)',
        borderTopLeftRadius: '100%',
        borderBottomLeftRadius: '100%',
        transform: 'translateX(50%)'
      }}></div>
      <div className="absolute top-0 left-2/3 w-52 h-26 opacity-16" style={{
        background: 'rgb(204, 153, 51)',
        borderBottomLeftRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateY(-50%)'
      }}></div>
      <div className="absolute bottom-1/2 left-0 w-36 h-18 opacity-13" style={{
        background: 'rgb(204, 153, 51)',
        borderTopRightRadius: '100%',
        borderBottomRightRadius: '100%',
        transform: 'translateX(-50%)'
      }}></div>
      <div className="absolute top-1/4 right-0 w-60 h-30 opacity-11" style={{
        background: 'rgb(204, 153, 51)',
        borderTopLeftRadius: '100%',
        borderBottomLeftRadius: '100%',
        transform: 'translateX(50%)'
      }}></div>
      
      {/* Geometric Pattern Overlay */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
        backgroundSize: '40px 40px'
      }}></div>
      
      <div className="relative z-10">
        {selectedUser ? (
          <UserProfile 
            user={selectedUser} 
            onBack={() => setSelectedUserId(null)}
            logo={logo}
          />
        ) : (
          <Dashboard 
            logo={logo} 
            onUserClick={(userId) => setSelectedUserId(userId)}
          />
        )}
      </div>
    </div>
  );
}
