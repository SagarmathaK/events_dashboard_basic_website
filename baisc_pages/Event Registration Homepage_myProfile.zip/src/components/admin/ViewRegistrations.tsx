import { useState } from 'react';
import { Registration } from '../../App';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Search, Download, Users } from 'lucide-react';
import { Button } from '../ui/button';

// Mock registrations data
const mockRegistrations: Registration[] = [
  {
    id: '1',
    eventId: '1',
    userId: '101',
    userName: 'Alice Johnson',
    userEmail: 'alice.j@college.edu',
    registeredAt: '2025-10-28T10:30:00Z',
  },
  {
    id: '2',
    eventId: '1',
    userId: '102',
    userName: 'Bob Smith',
    userEmail: 'bob.s@college.edu',
    registeredAt: '2025-10-28T11:45:00Z',
  },
  {
    id: '3',
    eventId: '2',
    userId: '103',
    userName: 'Carol Williams',
    userEmail: 'carol.w@college.edu',
    registeredAt: '2025-10-29T09:15:00Z',
  },
  {
    id: '4',
    eventId: '1',
    userId: '104',
    userName: 'David Brown',
    userEmail: 'david.b@college.edu',
    registeredAt: '2025-10-29T14:20:00Z',
  },
  {
    id: '5',
    eventId: '2',
    userId: '105',
    userName: 'Emma Davis',
    userEmail: 'emma.d@college.edu',
    registeredAt: '2025-10-30T08:00:00Z',
  },
];

const mockEvents = [
  { id: '1', title: 'Annual Tech Fest 2025' },
  { id: '2', title: 'Cultural Night 2025' },
  { id: '3', title: 'Career Fair 2025' },
];

export function ViewRegistrations() {
  const [registrations] = useState<Registration[]>(mockRegistrations);
  const [selectedEvent, setSelectedEvent] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRegistrations = registrations.filter(reg => {
    const matchesEvent = selectedEvent === 'all' || reg.eventId === selectedEvent;
    const matchesSearch = reg.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         reg.userEmail.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesEvent && matchesSearch;
  });

  const getEventTitle = (eventId: string) => {
    const event = mockEvents.find(e => e.id === eventId);
    return event?.title || 'Unknown Event';
  };

  const handleExport = () => {
    // Simple CSV export functionality
    const csv = [
      ['Name', 'Email', 'Event', 'Registration Date'],
      ...filteredRegistrations.map(reg => [
        reg.userName,
        reg.userEmail,
        getEventTitle(reg.eventId),
        new Date(reg.registeredAt).toLocaleString(),
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'registrations.csv';
    a.click();
  };

  const getRegistrationStats = () => {
    const stats = mockEvents.map(event => ({
      event: event.title,
      count: registrations.filter(r => r.eventId === event.id).length,
    }));
    return stats;
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Registrations</CardDescription>
            <CardTitle className="text-blue-600">{registrations.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Active Events</CardDescription>
            <CardTitle className="text-green-600">{mockEvents.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Unique Users</CardDescription>
            <CardTitle className="text-purple-600">
              {new Set(registrations.map(r => r.userId)).size}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Event-wise Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Registration Breakdown by Event</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {getRegistrationStats().map((stat, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">{stat.event}</span>
                </div>
                <Badge>{stat.count} registrations</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Registrations Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>All Registrations</CardTitle>
              <CardDescription>View and manage event registrations</CardDescription>
            </div>
            <Button onClick={handleExport} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedEvent} onValueChange={setSelectedEvent}>
              <SelectTrigger className="w-full sm:w-[250px]">
                <SelectValue placeholder="Filter by event" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                {mockEvents.map(event => (
                  <SelectItem key={event.id} value={event.id}>
                    {event.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Event</TableHead>
                  <TableHead>Registration Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRegistrations.length > 0 ? (
                  filteredRegistrations.map(reg => (
                    <TableRow key={reg.id}>
                      <TableCell>{reg.userName}</TableCell>
                      <TableCell>{reg.userEmail}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getEventTitle(reg.eventId)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(reg.registeredAt).toLocaleString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-gray-500">
                      No registrations found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
