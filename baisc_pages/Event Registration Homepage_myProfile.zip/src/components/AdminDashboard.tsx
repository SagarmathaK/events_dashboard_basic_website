import { useState } from 'react';
import { User } from '../App';
import { ManageEvents } from './admin/ManageEvents';
import { ViewRegistrations } from './admin/ViewRegistrations';
import { UserManagement } from './admin/UserManagement';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, LogOut, Home, CalendarDays, Users, UserCog } from 'lucide-react';
import { Footer } from './Footer';
import collegeLogo from 'figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png';

type AdminDashboardProps = {
  currentUser: User;
  onLogout: () => void;
  onBackToHome: () => void;
};

export function AdminDashboard({ currentUser, onLogout, onBackToHome }: AdminDashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="shadow-sm sticky top-0 z-10" style={{ backgroundColor: '#00306B' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={collegeLogo} alt="BMSCE Logo" className="w-22 h-22" />
              <div>
                <h1 className="text-white text-[27px]">Admin Dashboard</h1>
                <p className="text-gray-300 text-sm">Event Management Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm text-white">{currentUser.name}</p>
                <p className="text-xs text-gray-300">{currentUser.email}</p>
              </div>
              <Button onClick={onBackToHome} variant="outline" size="sm" className="border-white text-white hover:bg-white/10">
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
              <Button onClick={onLogout} variant="outline" size="sm" className="border-white text-white hover:bg-white/10">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="events" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="events" className="gap-2">
              <CalendarDays className="w-4 h-4" />
              Manage Events
            </TabsTrigger>
            <TabsTrigger value="registrations" className="gap-2">
              <Users className="w-4 h-4" />
              Registrations
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <UserCog className="w-4 h-4" />
              Users
            </TabsTrigger>
          </TabsList>

          <TabsContent value="events">
            <ManageEvents />
          </TabsContent>

          <TabsContent value="registrations">
            <ViewRegistrations />
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
}
