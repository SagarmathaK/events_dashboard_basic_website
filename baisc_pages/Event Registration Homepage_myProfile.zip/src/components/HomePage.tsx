import { useState } from 'react';
import { User, Event, Registration } from '../App';
import { EventCard } from './EventCard';
import { EventRegistrationDialog } from './EventRegistrationDialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, Search, User as UserIcon, LogOut, Settings } from 'lucide-react';
import { Badge } from './ui/badge';
import { Footer } from './Footer';
import collegeLogo from 'figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png';

// Mock events data
const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Annual Tech Fest 2025',
    description: 'Join us for the biggest technology festival featuring hackathons, workshops, and tech talks from industry leaders.',
    date: '2025-11-15',
    time: '9:00 AM - 6:00 PM',
    location: 'Main Auditorium',
    category: 'Technology',
    imageUrl: 'https://images.unsplash.com/photo-1646579886135-068c73800308?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwd29ya3Nob3AlMjBzZW1pbmFyfGVufDF8fHx8MTc2MjEwNzIzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 500,
    registered: 342,
    status: 'upcoming',
    website: 'https://example.com/techfest2025',
  },
  {
    id: '2',
    title: 'Cultural Night 2025',
    description: 'Experience the vibrant diversity of our college community through music, dance, and cultural performances.',
    date: '2025-11-08',
    time: '7:00 PM - 10:00 PM',
    location: 'Open Air Theatre',
    category: 'Cultural',
    imageUrl: 'https://images.unsplash.com/photo-1700087209989-5a83d1a7c484?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGNvbmNlcnQlMjBwZXJmb3JtYW5jZXxlbnwxfHx8fDE3NjIwNjgzNTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 800,
    registered: 654,
    status: 'upcoming',
    website: 'https://example.com/culturalnight2025',
  },
  {
    id: '3',
    title: 'Career Fair 2025',
    description: 'Meet top recruiters and explore career opportunities. Bring your resumes and dress professionally!',
    date: '2025-11-20',
    time: '10:00 AM - 4:00 PM',
    location: 'Sports Complex',
    category: 'Career',
    imageUrl: 'https://images.unsplash.com/photo-1676276374429-3902f2666824?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJlZXIlMjBmYWlyJTIwbmV0d29ya2luZ3xlbnwxfHx8fDE3NjIxMDcyMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 300,
    registered: 287,
    status: 'upcoming',
    website: 'https://example.com/careerfair2025',
  },
  {
    id: '4',
    title: 'Inter-College Sports Meet',
    description: 'Cheer for our teams as they compete in various sports including basketball, football, and athletics.',
    date: '2025-11-05',
    time: '8:00 AM - 5:00 PM',
    location: 'Sports Ground',
    category: 'Sports',
    imageUrl: 'https://images.unsplash.com/photo-1521534309669-61575d0047fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBjb21wZXRpdGlvbiUyMGZpZWxkfGVufDF8fHx8MTc2MjEwNzIzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 1000,
    registered: 156,
    status: 'upcoming',
    website: 'https://example.com/sportsmeet2025',
  },
  {
    id: '5',
    title: 'Art Exhibition: Student Showcase',
    description: "Explore creative masterpieces from our talented students. Paintings, sculptures, and digital art on display.",
    date: '2025-11-10',
    time: '11:00 AM - 6:00 PM',
    location: 'Arts Building Gallery',
    category: 'Arts',
    imageUrl: 'https://images.unsplash.com/photo-1723721229325-b286656e768a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBleGhpYml0aW9uJTIwZ2FsbGVyeXxlbnwxfHx8fDE3NjIwMDAxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 200,
    registered: 89,
    status: 'upcoming',
    website: 'https://example.com/artexhibition2025',
  },
  {
    id: '6',
    title: 'Orientation Day 2025',
    description: 'Welcome new students to our college family. Campus tours, meet faculty, and student activities.',
    date: '2025-11-03',
    time: '9:00 AM - 3:00 PM',
    location: 'Central Lawn',
    category: 'Academic',
    imageUrl: 'https://images.unsplash.com/photo-1613687969216-40c7b718c025?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2FtcHVzJTIwZXZlbnR8ZW58MXx8fHwxNzYyMDgwMjA3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    capacity: 600,
    registered: 543,
    status: 'ongoing',
    website: 'https://example.com/orientation2025',
  },
];

type HomePageProps = {
  currentUser: User | null;
  onLoginClick: () => void;
  onLogout: () => void;
  onAdminClick: () => void;
};

export function HomePage({ currentUser, onLoginClick, onLogout, onAdminClick }: HomePageProps) {
  const [events] = useState<Event[]>(mockEvents);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [registrationDialogOpen, setRegistrationDialogOpen] = useState(false);

  const handleRegisterClick = (event: Event) => {
    if (!currentUser) {
      onLoginClick();
      return;
    }
    setSelectedEvent(event);
    setRegistrationDialogOpen(true);
  };

  const handleRegistrationSubmit = (eventId: string, userName: string, userEmail: string) => {
    const newRegistration: Registration = {
      id: Math.random().toString(36).substr(2, 9),
      eventId,
      userId: currentUser?.id || '',
      userName,
      userEmail,
      registeredAt: new Date().toISOString(),
    };
    setRegistrations([...registrations, newRegistration]);
    setRegistrationDialogOpen(false);
  };

  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const upcomingEvents = filteredEvents.filter(e => e.status === 'upcoming');
  const ongoingEvents = filteredEvents.filter(e => e.status === 'ongoing');

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="shadow-sm sticky top-0 z-10" style={{ backgroundColor: '#00306B' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={collegeLogo} alt="BMSCE Logo" className="w-22 h-22" />
              <div>
                <h1 className="text-white text-[27px]">B.M.S COLLEGE OF ENGINEERING</h1>
                <p className="text-gray-300 text-sm">ESTD. 1946 Autonomous Institute, Affiliated to VTU</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {currentUser ? (
                <>
                  <div className="text-right hidden sm:block">
                    <p className="text-sm text-white">{currentUser.name}</p>
                    <Badge variant="secondary" className="text-xs">
                      {currentUser.role}
                    </Badge>
                  </div>
                  {currentUser.role === 'admin' && (
                    <Button onClick={onAdminClick} variant="outline" size="sm" className="border-white text-white hover:bg-white/10">
                      <Settings className="w-4 h-4 mr-2" />
                      Admin
                    </Button>
                  )}
                  <Button onClick={onLogout} variant="outline" size="sm" className="border-white text-white hover:bg-white/10">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button onClick={onLoginClick} className="bg-white text-[#00306B] hover:bg-gray-100" size="sm">
                  <UserIcon className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-white mb-4">Discover B.M.S COLLEGE OF ENGINEERING Events</h2>
          <p className="text-blue-100 max-w-2xl mb-8">
            Stay connected with everything happening on campus. Browse events, register, and be part of our vibrant community.
          </p>
          <div className="max-w-2xl relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search events by name, category, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white"
            />
          </div>
        </div>
      </div>

      {/* Events Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="all">All Events</TabsTrigger>
            <TabsTrigger value="ongoing">Ongoing</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {ongoingEvents.length > 0 && (
              <div>
                <h3 className="text-gray-900 mb-4">Happening Now</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {ongoingEvents.map(event => (
                    <EventCard
                      key={event.id}
                      event={event}
                      onRegister={handleRegisterClick}
                      isRegistered={registrations.some(r => r.eventId === event.id)}
                    />
                  ))}
                </div>
              </div>
            )}
            
            {upcomingEvents.length > 0 && (
              <div>
                <h3 className="text-gray-900 mb-4 mt-8">Upcoming Events</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {upcomingEvents.map(event => (
                    <EventCard
                      key={event.id}
                      event={event}
                      onRegister={handleRegisterClick}
                      isRegistered={registrations.some(r => r.eventId === event.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {filteredEvents.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No events found matching your search.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="ongoing">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ongoingEvents.map(event => (
                <EventCard
                  key={event.id}
                  event={event}
                  onRegister={handleRegisterClick}
                  isRegistered={registrations.some(r => r.eventId === event.id)}
                />
              ))}
            </div>
            {ongoingEvents.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No ongoing events at the moment.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="upcoming">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingEvents.map(event => (
                <EventCard
                  key={event.id}
                  event={event}
                  onRegister={handleRegisterClick}
                  isRegistered={registrations.some(r => r.eventId === event.id)}
                />
              ))}
            </div>
            {upcomingEvents.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No upcoming events scheduled.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Registration Dialog */}
      {selectedEvent && (
        <EventRegistrationDialog
          event={selectedEvent}
          isOpen={registrationDialogOpen}
          onClose={() => setRegistrationDialogOpen(false)}
          onSubmit={handleRegistrationSubmit}
          currentUser={currentUser}
        />
      )}

      <Footer />
    </div>
  );
}
