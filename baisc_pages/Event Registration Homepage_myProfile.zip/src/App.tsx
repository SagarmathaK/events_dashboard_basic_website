import { useState } from 'react';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { AdminDashboard } from './components/AdminDashboard';

export type User = {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
};

export type Event = {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: string;
  imageUrl: string;
  capacity: number;
  registered: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  website?: string;
};

export type Registration = {
  id: string;
  eventId: string;
  userId: string;
  userName: string;
  userEmail: string;
  registeredAt: string;
};

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'login' | 'admin'>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentPage('admin');
    } else {
      setCurrentPage('home');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('home');
  };

  const navigateToAdmin = () => {
    if (currentUser?.role === 'admin') {
      setCurrentPage('admin');
    }
  };

  const navigateToHome = () => {
    setCurrentPage('home');
  };

  const navigateToLogin = () => {
    setCurrentPage('login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentPage === 'home' && (
        <HomePage
          currentUser={currentUser}
          onLoginClick={navigateToLogin}
          onLogout={handleLogout}
          onAdminClick={navigateToAdmin}
        />
      )}
      {currentPage === 'login' && (
        <LoginPage onLogin={handleLogin} onBack={navigateToHome} />
      )}
      {currentPage === 'admin' && currentUser?.role === 'admin' && (
        <AdminDashboard
          currentUser={currentUser}
          onLogout={handleLogout}
          onBackToHome={navigateToHome}
        />
      )}
    </div>
  );
}

export default App;
