
  # Event Registration Homepage

  This is a code bundle for Event Registration Homepage. The original project is available at https://www.figma.com/design/mrC25tVzTSNWvs1UbFymA4/Event-Registration-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  