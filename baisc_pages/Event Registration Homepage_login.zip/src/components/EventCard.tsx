import { Event } from '../App';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, Clock, MapPin, Users, CheckCircle, ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

type EventCardProps = {
  event: Event;
  onRegister: (event: Event) => void;
  isRegistered: boolean;
};

export function EventCard({ event, onRegister, isRegistered }: EventCardProps) {
  const availableSpots = event.capacity - event.registered;
  const isAlmostFull = availableSpots <= event.capacity * 0.2;
  const isFull = availableSpots <= 0;

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Technology: 'bg-blue-100 text-blue-800',
      Cultural: 'bg-purple-100 text-purple-800',
      Sports: 'bg-green-100 text-green-800',
      Career: 'bg-orange-100 text-orange-800',
      Arts: 'bg-pink-100 text-pink-800',
      Academic: 'bg-indigo-100 text-indigo-800',
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-48 overflow-hidden">
        <ImageWithFallback
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <Badge className={getCategoryColor(event.category)}>
            {event.category}
          </Badge>
        </div>
        {event.status === 'ongoing' && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-red-500 text-white">Live Now</Badge>
          </div>
        )}
      </div>

      <CardHeader>
        <CardTitle>{event.title}</CardTitle>
        <CardDescription className="line-clamp-2">{event.description}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>{new Date(event.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock className="w-4 h-4" />
          <span>{event.time}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <MapPin className="w-4 h-4" />
          <span>{event.location}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Users className="w-4 h-4" />
          <span>
            {event.registered} / {event.capacity} registered
            {isAlmostFull && !isFull && (
              <span className="text-orange-600 ml-2">• Almost Full!</span>
            )}
            {isFull && (
              <span className="text-red-600 ml-2">• Full</span>
            )}
          </span>
        </div>
      </CardContent>

      <CardFooter className="flex gap-2">
        {isRegistered ? (
          <Button variant="outline" className="flex-1" disabled>
            <CheckCircle className="w-4 h-4 mr-2" />
            Registered
          </Button>
        ) : (
          <Button 
            onClick={() => onRegister(event)} 
            className="flex-1"
            disabled={isFull}
          >
            {isFull ? 'Event Full' : 'Register Now'}
          </Button>
        )}
        {event.website && (
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => window.open(event.website, '_blank')}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Check Event
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
