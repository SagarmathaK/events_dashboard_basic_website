export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-6 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} B.M.S COLLEGE OF ENGINEERING. All rights reserved.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            ESTD. 1946 | Autonomous Institute, Affiliated to VTU
          </p>
          <p className="text-gray-500 text-xs mt-1">
            Contact Us: events.admin@bmsce.ac.in
          </p>
        </div>
      </div>
    </footer>
  );
}
