export function Footer() {
  return (
    <footer className="relative z-10 mt-16 border-t border-white/10 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-white/70 text-center md:text-left">
            <p>© 2025 B.M.S. College of Engineering. All rights reserved.</p>
            <p className="mt-1">Contact Us: <a href="mailto:events.admin@bmsce.ac.in" className="hover:text-white transition-colors">events.admin@bmsce.ac.in</a></p>
          </div>
          <div className="flex gap-6 text-white/70">
            <a href="#" className="hover:text-white transition-colors">About</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
