import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Mail, Phone, GraduationCap, Heart, Users, Linkedin, Github, Globe } from 'lucide-react';

interface ProfilePreviewProps {
  profileData: {
    firstName: string;
    lastName: string;
    email: string;
    studentId: string;
    phone: string;
    department: string;
    academicYear: string;
    bio: string;
    interests: string;
    clubs: string;
    linkedin: string;
    github: string;
    portfolio: string;
    avatar: string;
  };
}

export function ProfilePreview({ profileData }: ProfilePreviewProps) {
  const getInitials = () => {
    const first = profileData.firstName?.[0] || '';
    const last = profileData.lastName?.[0] || '';
    return (first + last).toUpperCase();
  };

  const formatText = (text: string) => {
    return text
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const hasContent =
    profileData.firstName ||
    profileData.lastName ||
    profileData.email ||
    profileData.department ||
    profileData.bio;

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Card className="max-w-md w-full">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <GraduationCap className="w-16 h-16 text-gray-300 mb-4" />
            <p className="text-gray-500 text-center">
              Start editing your profile to see a preview here
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="overflow-hidden">
        {/* Header Banner */}
        <div className="h-32 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>

        {/* Profile Content */}
        <CardContent className="relative pt-16 pb-8">
          {/* Avatar */}
          <div className="absolute -top-16 left-8">
            <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
              <AvatarImage src={profileData.avatar} />
              <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-400 text-white">
                {getInitials() || 'CN'}
              </AvatarFallback>
            </Avatar>
          </div>

          {/* Name and Year */}
          <div className="ml-44 mb-6">
            <h2 className="mb-1">
              {profileData.firstName} {profileData.lastName}
            </h2>
            {profileData.academicYear && (
              <Badge variant="secondary" className="mb-2">
                {formatText(profileData.academicYear)}
              </Badge>
            )}
            {profileData.studentId && (
              <p className="text-gray-600">USN: {profileData.studentId}</p>
            )}
          </div>

          {/* Contact Info */}
          {(profileData.email || profileData.phone) && (
            <div className="mb-6 space-y-2">
              {profileData.email && (
                <div className="flex items-center gap-2 text-gray-700">
                  <Mail className="w-4 h-4" />
                  <a href={`mailto:${profileData.email}`} className="hover:text-blue-600">
                    {profileData.email}
                  </a>
                </div>
              )}
              {profileData.phone && (
                <div className="flex items-center gap-2 text-gray-700">
                  <Phone className="w-4 h-4" />
                  <span>{profileData.phone}</span>
                </div>
              )}
            </div>
          )}

          <Separator className="my-6" />

          {/* Bio */}
          {profileData.bio && (
            <div className="mb-6">
              <h3 className="mb-2">About</h3>
              <p className="text-gray-700 leading-relaxed">{profileData.bio}</p>
            </div>
          )}

          {/* Academic Information */}
          {(profileData.department || profileData.academicYear) && (
            <>
              <Separator className="my-6" />
              <div className="mb-6">
                <h3 className="mb-4 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  Academic Information
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {profileData.department && (
                    <div>
                      <p className="text-gray-600 text-sm">Department</p>
                      <p>{formatText(profileData.department)}</p>
                    </div>
                  )}
                  {profileData.academicYear && (
                    <div>
                      <p className="text-gray-600 text-sm">Academic Year</p>
                      <p>{formatText(profileData.academicYear)}</p>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* Interests */}
          {profileData.interests && (
            <>
              <Separator className="my-6" />
              <div className="mb-6">
                <h3 className="mb-3 flex items-center gap-2">
                  <Heart className="w-5 h-5" />
                  Interests
                </h3>
                <div className="flex flex-wrap gap-2">
                  {profileData.interests
                    .split(',')
                    .map((interest, index) => (
                      <Badge key={index} variant="outline">
                        {interest.trim()}
                      </Badge>
                    ))}
                </div>
              </div>
            </>
          )}

          {/* Clubs & Organizations */}
          {profileData.clubs && (
            <>
              <Separator className="my-6" />
              <div className="mb-6">
                <h3 className="mb-3 flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Clubs & Organizations
                </h3>
                <div className="flex flex-wrap gap-2">
                  {profileData.clubs
                    .split(',')
                    .map((club, index) => (
                      <Badge key={index} variant="secondary">
                        {club.trim()}
                      </Badge>
                    ))}
                </div>
              </div>
            </>
          )}

          {/* Social Links */}
          {(profileData.linkedin || profileData.github || profileData.portfolio) && (
            <>
              <Separator className="my-6" />
              <div>
                <h3 className="mb-3">Connect</h3>
                <div className="flex flex-wrap gap-3">
                  {profileData.linkedin && (
                    <a
                      href={profileData.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  )}
                  {profileData.github && (
                    <a
                      href={profileData.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors"
                    >
                      <Github className="w-4 h-4" />
                      GitHub
                    </a>
                  )}
                  {profileData.portfolio && (
                    <a
                      href={profileData.portfolio}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Globe className="w-4 h-4" />
                      Portfolio
                    </a>
                  )}
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
