import { useState } from 'react';
import { ProfileForm } from './components/ProfileForm';
import { ProfilePreview } from './components/ProfilePreview';
import { Footer } from './components/Footer';
import { Button } from './components/ui/button';
import { User } from 'lucide-react';
import logo from 'figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png';

export default function App() {
  const [showPreview, setShowPreview] = useState(false);
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    studentId: '',
    phone: '',
    countryCode: '+91',
    address: '',
    department: '',
    academicYear: '',
    bio: '',
    interests: '',
    clubs: '',
    linkedin: '',
    github: '',
    collegeGithub: '',
    portfolio: '',
    avatar: '',
  });

  const handleUpdateProfile = (data: typeof profileData) => {
    setProfileData(data);
  };

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #00306B 0%, #001f4d 50%, #003d82 100%)' }}>
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #4a90e2 0%, transparent 70%)', transform: 'translate(30%, -30%)' }}></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #5ba3f5 0%, transparent 70%)', transform: 'translate(-30%, 30%)' }}></div>
        <div className="absolute top-1/2 left-1/2 w-72 h-72 rounded-full opacity-5" style={{ background: 'radial-gradient(circle, #6cb4ff 0%, transparent 70%)', transform: 'translate(-50%, -50%)' }}></div>
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-6xl relative z-10">
        <div className="mb-8 flex items-center justify-between">
          <img src={logo} alt="B.M.S. College of Engineering" className="w-32 h-32" />
          <h1 className="text-white absolute left-1/2 transform -translate-x-1/2">{showPreview ? 'Your Profile' : 'Edit your Profile'}</h1>
          <Button 
            onClick={() => setShowPreview(!showPreview)}
            variant="outline"
            className="bg-white/10 text-white border-white/20 hover:bg-white/20 hover:text-white"
          >
            <User className="w-4 h-4 mr-2" />
            {showPreview ? 'Edit Profile' : 'View Profile'}
          </Button>
        </div>

        {showPreview ? (
          <ProfilePreview profileData={profileData} />
        ) : (
          <ProfileForm profileData={profileData} onUpdate={handleUpdateProfile} />
        )}

        <Footer />
      </div>
    </div>
  );
}
