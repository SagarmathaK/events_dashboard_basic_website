
  # College Profile Customization Page

  This is a code bundle for College Profile Customization Page. The original project is available at https://www.figma.com/design/yvDwHuURlvXYSSVMz6c3B8/College-Profile-Customization-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  