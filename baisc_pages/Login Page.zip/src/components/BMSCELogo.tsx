import bmsceLogoImg from "figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png";

export function BMSCELogo() {
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        {/* Logo container with circular background */}
        <div className="relative bg-white rounded-full" style={{ padding: '0.8rem' }}>
          <img 
            src={bmsceLogoImg} 
            alt="BMS College of Engineering Logo" 
            style={{ width: '189px', height: '189px' }}
            className="object-contain"
          />
        </div>
      </div>
    </div>
  );
}
