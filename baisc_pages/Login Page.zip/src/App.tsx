import { LoginForm } from "./components/LoginForm";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center relative overflow-hidden" style={{ backgroundColor: '#001F47' }}>
      {/* Decorative background circles */}
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 191, 0)',
          width: '500px',
          height: '500px',
          top: '-150px',
          right: '-100px'
        }}
      />
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 191, 0)',
          width: '400px',
          height: '400px',
          bottom: '-100px',
          left: '-100px'
        }}
      />
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 191, 0)',
          width: '350px',
          height: '350px',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)'
        }}
      />

      {/* Red/coral circular spots on left diagonal */}
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 111, 97)',
          width: '450px',
          height: '450px',
          top: '-100px',
          left: '-150px'
        }}
      />
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 111, 97)',
          width: '380px',
          height: '380px',
          top: '35%',
          left: '-50px'
        }}
      />
      <div 
        className="absolute rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ 
          backgroundColor: 'rgb(255, 111, 97)',
          width: '420px',
          height: '420px',
          bottom: '-150px',
          left: '100px'
        }}
      />
      
      <LoginForm />
    </div>
  );
}
