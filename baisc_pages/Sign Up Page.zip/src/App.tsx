import { SignUpForm } from "./components/SignUpForm";

export default function App() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 relative overflow-hidden" style={{ backgroundColor: '#00306B' }}>
      {/* Decorative blur elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-cyan-400/15 rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-indigo-400/10 rounded-full blur-3xl"></div>
      
      {/* Golden/Amber blur elements */}
      <div 
        className="absolute top-20 right-1/4 w-80 h-80 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.12)' }}
      ></div>
      <div 
        className="absolute bottom-20 left-1/4 w-72 h-72 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.15)' }}
      ></div>
      <div 
        className="absolute top-1/3 right-10 w-56 h-56 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.08)' }}
      ></div>
      <div 
        className="absolute top-40 left-10 w-64 h-64 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.1)' }}
      ></div>
      <div 
        className="absolute bottom-32 right-1/3 w-88 h-88 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.13)' }}
      ></div>
      <div 
        className="absolute top-2/3 left-1/2 w-60 h-60 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.09)' }}
      ></div>
      
      {/* Golden semi-circles */}
      <div 
        className="absolute -top-32 left-1/4 w-96 h-96 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.14)' }}
      ></div>
      <div 
        className="absolute -bottom-40 right-1/3 w-[500px] h-[500px] rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.16)' }}
      ></div>
      <div 
        className="absolute top-1/2 -left-48 w-80 h-80 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.11)' }}
      ></div>
      <div 
        className="absolute top-1/4 -right-40 w-96 h-96 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.13)' }}
      ></div>
      <div 
        className="absolute -bottom-24 left-10 w-72 h-72 rounded-full blur-3xl" 
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.12)' }}
      ></div>
      
      {/* Decorative rings and geometric shapes */}
      <div 
        className="absolute bottom-1/4 left-1/3 w-80 h-80 rounded-full border-2 opacity-10 blur-sm"
        style={{ borderColor: 'rgba(100, 200, 255, 0.6)' }}
      ></div>
      
      {/* Geometric accent shapes */}
      <div 
        className="absolute top-16 left-1/2 w-32 h-32 rotate-45 opacity-5 blur-sm"
        style={{ backgroundColor: 'rgba(255, 191, 0, 0.3)' }}
      ></div>
      <div 
        className="absolute bottom-20 right-1/4 w-24 h-24 rotate-12 opacity-5 blur-sm"
        style={{ backgroundColor: 'rgba(100, 200, 255, 0.3)' }}
      ></div>
      
      {/* Gradient overlays */}
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          background: 'radial-gradient(circle at 20% 30%, rgba(255, 191, 0, 0.08) 0%, transparent 50%)'
        }}
      ></div>
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          background: 'radial-gradient(circle at 80% 70%, rgba(100, 200, 255, 0.08) 0%, transparent 50%)'
        }}
      ></div>
      
      {/* Form content */}
      <div className="relative z-10">
        <SignUpForm />
      </div>
    </div>
  );
}
