import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import logo from "figma:asset/87f8c83b4599481883f1eedb3d235a5d4ef58eac.png";

export function SignUpForm() {
  const [formData, setFormData] = useState({
    usn: "",
    fullName: "",
    department: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle sign-up logic here
    console.log("Sign up submitted:", formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleDepartmentChange = (value: string) => {
    setFormData({
      ...formData,
      department: value
    });
  };

  return (
    <Card className="w-full max-w-md shadow-xl">
      <CardHeader className="space-y-4">
        <div className="flex justify-center">
          <img src={logo} alt="B.M.S. College of Engineering" className="w-24 h-24" />
        </div>
        <CardDescription className="text-center text-foreground">
          Enter your information to get started
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fullName">Full Name</Label>
            <Input
              id="fullName"
              name="fullName"
              type="text"
              placeholder="John Doe"
              value={formData.fullName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="usn">USN</Label>
            <Input
              id="usn"
              name="usn"
              type="text"
              placeholder="Enter your USN"
              value={formData.usn}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="department">Department</Label>
            <Select onValueChange={handleDepartmentChange} value={formData.department} required>
              <SelectTrigger>
                <SelectValue placeholder="Select your department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="CSE">Computer Science and Engineering (CSE)</SelectItem>
                <SelectItem value="ISE">Information Science and Engineering (ISE)</SelectItem>
                <SelectItem value="ECE">Electronics and Communication Engineering (ECE)</SelectItem>
                <SelectItem value="EEE">Electrical and Electronics Engineering (EEE)</SelectItem>
                <SelectItem value="ME">Mechanical Engineering (ME)</SelectItem>
                <SelectItem value="CE">Civil Engineering (CE)</SelectItem>
                <SelectItem value="IEM">Industrial Engineering and Management (IEM)</SelectItem>
                <SelectItem value="ETE">Electronics and Telecommunication Engineering (ETE)</SelectItem>
                <SelectItem value="AE">Aerospace Engineering (AE)</SelectItem>
                <SelectItem value="AU">Automobile Engineering (AU)</SelectItem>
                <SelectItem value="AI&ML">Artificial Intelligence and Machine Learning (AI & ML)</SelectItem>
                <SelectItem value="BT">Biotechnology (BT)</SelectItem>
                <SelectItem value="MLE">Medical Electronics Engineering (MLE)</SelectItem>
                <SelectItem value="RME">Robotics and Mechatronics Engineering (RME)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="john@example.com"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              name="password"
              type="password"
              placeholder="Create a password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirm Password</Label>
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              placeholder="Confirm your password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>
          <Button type="submit" className="w-full">
            Sign Up
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <p className="text-center text-muted-foreground text-xs">
          Already have an account?{" "}
          <a href="#" className="text-primary hover:underline text-sm">
            Sign in
          </a>
        </p>
        <p className="text-center text-muted-foreground text-xs">
          By signing up, you agree to our{" "}
          <a href="#" className="text-primary hover:underline">
            Terms of Service
          </a>{" "}
          and{" "}
          <a href="#" className="text-primary hover:underline">
            Privacy Policy
          </a>
        </p>
      </CardFooter>
    </Card>
  );
}
